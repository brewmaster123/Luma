#if os(iOS)
  import Foundation
  import AVFoundation
  import Combine
  import UIKit
  import AudioToolbox

  enum AudioMonitoringOwner: Hashable {
    case rem
    case pairedAlarm
  }

  @MainActor
  final class PhoneAudio: NSObject, ObservableObject, AVAudioRecorderDelegate, AVAudioPlayerDelegate
  {
    @Published private(set) var monitoring = false
    @Published private(set) var recording = false
    @Published private(set) var playing = false
    @Published private(set) var recordSeconds = 0.0
    @Published private(set) var recordingJournal = false
    @Published private(set) var playbackID: UUID?
    @Published private(set) var playbackSeconds = 0.0
    private var preparingCapture = false
    private var journalCompletion: ((JournalVoice) -> Void)?
    private var hapticTask: Task<Void, Never>?
    private var playbackTimer: Timer?
    private var playbackStopper: CuePlaybackStopper?
    private var playbackGeneration = UUID()
    private var backgroundTask: UIBackgroundTaskIdentifier = .invalid
    var externalPlaybackActive: () -> Bool = { false }
    var onEpoch: ((AudioEpoch) -> Void)?
    var onClip: ((VoiceClip) -> Void)?
    var onError: ((String) -> Void)?
    var onInterruption: ((String) -> Void)?
    private let engine = AVAudioEngine()
    private var recorder: AVAudioRecorder?
    private var player: AVAudioPlayer?
    private var timer: Timer?
    private var observers: [NSObjectProtocol] = []
    private var recordingID: UUID?
    private var name = "Моя подсказка"
    private var tap = false
    private var excludedUntil = Date.distantPast
    private var cueExclusions: [DateInterval] = []
    private var monitoringGeneration = UUID()
    private var monitoringStarted: Date?
    private var lastInput: Date?
    private var monitoringOwners = Set<AudioMonitoringOwner>()
    var hasLiveInput: Bool {
      monitoring && engine.isRunning && PairedCuePolicy.microphoneIsFresh(lastInput: lastInput, now: Date())
    }
    func checkInputLiveness() {
      guard monitoring, let started = monitoringStarted,
        Date().timeIntervalSince(started) > 4, !hasLiveInput else { return }
      interrupt()
    }
    func excludeFromDetection(from start: Date, until end: Date) {
      guard end > start else { return }
      cueExclusions.removeAll { $0.end < Date().addingTimeInterval(-900) }
      let interval = DateInterval(start: start, end: end)
      if !cueExclusions.contains(interval) { cueExclusions.append(interval) }
    }
    override init() {
      super.init()
      observers.append(
        NotificationCenter.default.addObserver(
          forName: AVAudioSession.interruptionNotification, object: nil, queue: .main
        ) { [weak self] n in
          guard
            n.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt
              == AVAudioSession.InterruptionType.began.rawValue
          else { return }
          Task { @MainActor in self?.interrupt() }
        })
      observers.append(
        NotificationCenter.default.addObserver(
          forName: .AVAudioEngineConfigurationChange, object: engine, queue: .main
        ) { [weak self] _ in
          Task { @MainActor in
            if let self, self.monitoring, !self.engine.isRunning { self.interrupt() }
          }
        })
      observers.append(
        NotificationCenter.default.addObserver(
          forName: AVAudioSession.routeChangeNotification, object: nil, queue: .main
        ) { [weak self] note in
          Task { @MainActor in
            guard let self, self.monitoring else { return }
            let raw = note.userInfo?[AVAudioSessionRouteChangeReasonKey] as? UInt
            guard raw != AVAudioSession.RouteChangeReason.categoryChange.rawValue else { return }
            // The recording engine already owns an active background audio session.
            // Re-activating a nonmixable session after lock can fail with
            // AVAudioSession.ErrorCode.cannotInterruptOthers (!int / 560557684).
            // Preserve the live session and only reassert the built-in speaker route.
            if self.engine.isRunning {
              try? AVAudioSession.sharedInstance().overrideOutputAudioPort(.speaker)
            } else {
              self.interrupt()
            }
          }
        })
    }
    func soundsDirectory() throws -> URL {
      var d = try FileManager.default.url(
        for: .libraryDirectory, in: .userDomainMask, appropriateFor: nil, create: true
      ).appendingPathComponent("Sounds")
      try FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
      try FileManager.default.setAttributes(
        [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: d.path)
      var values = URLResourceValues()
      values.isExcludedFromBackup = true
      try d.setResourceValues(values)
      return d
    }
    func soundURL(_ s: SignalSettings, clips: [VoiceClip]) throws -> URL {
      if let id = s.voiceID {
        guard let clip = clips.first(where: { $0.id == id }), clip.duration > 0, clip.duration < 29,
          ["luma-voice-\(id.uuidString).caf", "luma-import-\(id.uuidString).caf"].contains(clip.filename)
        else { throw AppError.message("Выберите доступную голосовую дорожку.") }
        let url = try soundsDirectory().appendingPathComponent(clip.filename)
        guard FileManager.default.fileExists(atPath: url.path) else {
          throw AppError.message("Файл дорожки не найден.")
        }
        // Preparation happens before the night starts. Imported/recorded cues
        // must remain readable after the phone locks, just like session state.
        try FileManager.default.setAttributes(
          [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: url.path)
        return url
      }
      guard
        let url = Bundle.main.url(
          forResource: "luma-tone-\(s.validated().melodySeconds)", withExtension: "wav")
      else { throw AppError.message("Мелодия не найдена.") }
      return url
    }
    func notificationSound(_ signal: SignalSettings, clips: [VoiceClip]) throws -> NotificationService.Sound {
      let url = try soundURL(signal, clips: clips)
      let file = try AVAudioFile(forReading: url)
      let duration = Double(file.length) / file.processingFormat.sampleRate
      guard duration.isFinite, duration > 0, duration <= 28 else {
        throw AppError.message("Выберите звук длительностью до 28 секунд.")
      }
      return NotificationService.Sound(name: url.lastPathComponent, duration: duration)
    }
    func permission() async throws {
      let allowed: Bool = await withCheckedContinuation { c in
        AVAudioSession.sharedInstance().requestRecordPermission { c.resume(returning: $0) }
      }
      guard allowed else { throw AppError.message("Разрешите микрофон: Настройки iPhone → Luma.") }
    }
    private func activate(record: Bool) throws {
      let s = AVAudioSession.sharedInstance()
      try s.setCategory(
        record ? .playAndRecord : .playback, mode: .default,
        options: record ? [.defaultToSpeaker, .mixWithOthers] : [.mixWithOthers])
      try s.setActive(true)
      if record {
        try s.setAllowHapticsAndSystemSoundsDuringRecording(true)
        try s.overrideOutputAudioPort(.speaker)
      }
    }
    /// Prepare phone playback for a cue without reactivating an already-live
    /// background play-and-record session.
    private func activateForCue() throws {
      // If the microphone engine is running, its playAndRecord session is already
      // active and eligible for background audio. Do not call setActive(true) again
      // while the app is locked/backgrounded: iOS can reject that with !int.
      if monitoring && engine.isRunning { return }
      try activate(record: false)
    }
    func startMonitoring(owner: AudioMonitoringOwner) async throws {
      guard !recording, !preparingCapture else { throw AppError.message("Сначала завершите запись.") }
      if monitoring {
        monitoringOwners.insert(owner)
        return
      }
      try await permission()
      guard !recording, !preparingCapture else { throw AppError.message("Сначала завершите запись.") }
      try activate(record: true)
      let input = engine.inputNode
      let format = input.outputFormat(forBus: 0)
      guard format.sampleRate > 0, format.channelCount > 0 else {
        throw AppError.message("Микрофон недоступен.")
      }
      let accumulator = EnvelopeAccumulator(rate: format.sampleRate)
      let generation = UUID()
      monitoringGeneration = generation; monitoringStarted = Date(); lastInput = nil
      input.installTap(onBus: 0, bufferSize: 4096, format: format) { [weak self] b, _ in
        guard let data = b.floatChannelData?[0] else { return }
        accumulator.append(data, count: Int(b.frameLength), pulse: { date in
          Task { @MainActor in
            guard let self, self.monitoring, self.monitoringGeneration == generation else { return }
            let first = self.lastInput == nil
            self.lastInput = date
            if first { self.objectWillChange.send() }
          }
        }) { values, start, end in
          guard let epoch = AcousticFeatures.extract(envelope: values, start: start, end: end)
          else { return }
          Task { @MainActor in
            guard let self, self.monitoring, self.monitoringGeneration == generation else { return }
            var e = epoch
            e.contaminated = e.start < self.excludedUntil
              || self.cueExclusions.contains { $0.start < e.end && $0.end > e.start }
            self.onEpoch?(e)
          }
        }
      }
      tap = true
      monitoringOwners.insert(owner)
      do {
        try engine.start()
        monitoring = true
      } catch {
        monitoringOwners.remove(owner)
        stopAllMonitoring()
        throw error
      }
    }
    func stopMonitoring(owner: AudioMonitoringOwner) {
      monitoringOwners.remove(owner)
      guard monitoringOwners.isEmpty else { return }
      stopAllMonitoring()
    }
    func stopAllMonitoring() {
      monitoringOwners.removeAll()
      monitoringGeneration = UUID(); monitoringStarted = nil; lastInput = nil
      monitoring = false
      engine.stop()
      if tap {
        engine.inputNode.removeTap(onBus: 0)
        tap = false
      }
      deactivate()
    }
    func journalDirectory() throws -> URL {
      var directory = try FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask,
        appropriateFor: nil, create: true).appendingPathComponent("Luma/JournalAudio", isDirectory: true)
      try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
      var values = URLResourceValues(); values.isExcludedFromBackup = true
      try directory.setResourceValues(values)
      return directory
    }
    func journalURL(_ voice: JournalVoice) throws -> URL {
      guard voice.hasSafeFilename, voice.duration > 0, voice.duration < 1801 else {
        throw AppError.message("Файл голосовой заметки недоступен.")
      }
      let url = try journalDirectory().appendingPathComponent(voice.filename)
      guard FileManager.default.fileExists(atPath: url.path) else { throw AppError.message("Запись не найдена на iPhone.") }
      return url
    }
    func startRecording(name: String) async throws { try await startCapture(name: name, journal: nil) }
    func startJournalRecording(completion: @escaping (JournalVoice) -> Void) async throws {
      try await startCapture(name: "", journal: completion)
    }
    private func startCapture(name: String, journal: ((JournalVoice) -> Void)?) async throws {
      guard !monitoring, !recording, !preparingCapture, !externalPlaybackActive() else { throw AppError.message("Остановите ночной фон перед записью.") }
      preparingCapture = true
      defer { preparingCapture = false }
      stopPlayback()
      try await permission()
      guard !monitoring, !recording else { throw AppError.message("Завершите ночной сеанс.") }
      try activate(record: true)
      let id = UUID(), isJournal = journal != nil
      let url = try (isJournal ? journalDirectory() : soundsDirectory())
        .appendingPathComponent(isJournal ? "luma-journal-\(id.uuidString).m4a" : "luma-voice-\(id.uuidString).caf")
      do {
        let settings: [String: Any] = isJournal
          ? [AVFormatIDKey: kAudioFormatMPEG4AAC, AVSampleRateKey: 44100.0, AVNumberOfChannelsKey: 1, AVEncoderBitRateKey: 64000]
          : [AVFormatIDKey: kAudioFormatLinearPCM, AVSampleRateKey: 22050.0, AVNumberOfChannelsKey: 1,
             AVLinearPCMBitDepthKey: 16, AVLinearPCMIsFloatKey: false, AVLinearPCMIsBigEndianKey: false]
        let capture = try AVAudioRecorder(url: url, settings: settings)
        capture.delegate = self; recorder = capture; recordingID = id
        self.name = String(name.prefix(60)); journalCompletion = journal; recordingJournal = isJournal
        guard capture.record(forDuration: isJournal ? 1800 : 28) else { throw AppError.message("Не удалось начать запись.") }
        recording = true; recordSeconds = 0
        timer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { [weak self] _ in
          Task { @MainActor in self?.recordSeconds = self?.recorder?.currentTime ?? 0 }
        }
      } catch {
        recorder = nil; recordingID = nil; journalCompletion = nil; recordingJournal = false
        try? FileManager.default.removeItem(at: url); deactivate(); throw error
      }
    }
    func finishRecording() {
      guard let capture = recorder else { return }
      capture.stop()
      completeRecording(url: capture.url, success: true)
    }
    private func completeRecording(url: URL, success: Bool) {
      guard let id = recordingID, recorder?.url == url else { return }
      let isJournal = recordingJournal, completion = journalCompletion, clipName = name
      recordingID = nil; journalCompletion = nil; recorder = nil
      timer?.invalidate(); timer = nil; recording = false; recordingJournal = false
      defer { deactivate() }
      do {
        guard success else { throw AppError.message("Запись прервалась.") }
        let file = try AVAudioFile(forReading: url)
        let duration = Double(file.length) / file.processingFormat.sampleRate
        guard duration > 0.3, duration < (isJournal ? 1801 : 29) else { throw AppError.message("Запись слишком короткая. Попробуйте ещё раз.") }
        try FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: url.path)
        if isJournal { completion?(JournalVoice(id: id, filename: url.lastPathComponent, duration: duration)) }
        else { onClip?(VoiceClip(id: id, name: clipName.isEmpty ? "Моя подсказка" : clipName, filename: url.lastPathComponent, duration: duration)) }
      } catch { try? FileManager.default.removeItem(at: url); onError?(error.localizedDescription) }
    }
    func importSound(from source: URL) async throws -> VoiceClip {
      guard !monitoring, !recording, !preparingCapture else { throw AppError.message("Добавляйте мелодии между сеансами.") }
      let access = source.startAccessingSecurityScopedResource()
      defer { if access { source.stopAccessingSecurityScopedResource() } }
      let directory = try soundsDirectory()
      return try await Task.detached(priority: .userInitiated) { try CueAudioImporter.convert(source: source, directory: directory) }.value
    }
    func play(_ signal: SignalSettings, clips: [VoiceClip], vibrate: Bool = false) throws {
      if recording { finishRecording() }
      let sound = try notificationSound(signal, clips: clips)
      try playFile(soundURL(signal, clips: clips), id: signal.voiceID, vibrate: vibrate,
        cueDuration: sound.duration)
    }
    func playJournal(_ voice: JournalVoice) throws {
      guard !recording, !monitoring, !externalPlaybackActive() else { throw AppError.message("Завершите запись или ночной фон перед прослушиванием.") }
      try playFile(journalURL(voice), id: voice.id, vibrate: false)
    }
    /// Real finite playback independent of notification mirroring; no background wake-up.
    func playCue(_ signal: SignalSettings, clips: [VoiceClip], at start: Date? = nil,
      vibrate: Bool = false) throws {
      guard !recording, !playing else { throw AppError.message("Другой звук или запись уже выполняется.") }
      let sound = try notificationSound(signal, clips: clips)
      if let start, !(-2...10).contains(start.timeIntervalSinceNow) {
        throw AppError.message("Время совместного сигнала прошло.")
      }
      guard AVAudioSession.sharedInstance().outputVolume > 0 else {
        throw AppError.message("Поднимите громкость мультимедиа iPhone и повторите пробу.")
      }
      try playFile(soundURL(signal, clips: clips), id: signal.voiceID, vibrate: vibrate,
        at: start, cueDuration: sound.duration)
    }
    private func playFile(_ url: URL, id: UUID?, vibrate: Bool, at start: Date? = nil,
      cueDuration: TimeInterval? = nil) throws {
      stopPlayback()
      let generation = UUID(); playbackGeneration = generation
      // Bridges a sensor callback into genuine audio playback; does not create background wake-ups.
      backgroundTask = UIApplication.shared.beginBackgroundTask(withName: "Luma sound") { [weak self] in
        Task { @MainActor in
          guard let self, self.playbackGeneration == generation else { return }
          self.stopPlayback()
        }
      }
      do {
        // If monitoring is alive, use that already-active background session.
        // Re-activating it here after lock caused !int / cannotInterruptOthers in 0.5.1.
        try activateForCue()
        let next = try AVAudioPlayer(contentsOf: url)
        next.numberOfLoops = 0; next.volume = 1; next.delegate = self
        next.enableRate = false
        guard next.duration.isFinite, next.duration > 0 else {
          throw AppError.message("Не удалось определить длительность звука.")
        }
        guard next.prepareToPlay() else { throw AppError.message("Не удалось подготовить звук iPhone.") }
        player = next
        let delay = max(0, start?.timeIntervalSinceNow ?? 0)
        excludedUntil = Date().addingTimeInterval(delay + next.duration + 90)
        let accepted = delay > 0 ? next.play(atTime: next.deviceCurrentTime + delay) : next.play()
        guard accepted else { throw AppError.message("Не удалось воспроизвести звук.") }
        playbackID = id; playbackSeconds = 0; playing = true
        if let cueDuration {
          // The audio stop runs on a separate queue even if the player delegate or
          // UI run loop is delayed. Capture this player, never whichever plays next.
          playbackStopper = try CuePlaybackStopper(duration: cueDuration, startDelay: delay) { [weak self] in
            next.stop()
            Task { @MainActor in
              guard let self, self.playbackGeneration == generation, self.player === next else { return }
              self.stopPlayback()
            }
          }
        }
        playbackTimer = Timer.scheduledTimer(withTimeInterval: 0.25, repeats: true) { [weak self] _ in
          Task { @MainActor in self?.playbackSeconds = self?.player?.currentTime ?? 0 }
        }
        if vibrate {
          let duration = min(28, next.duration)
          hapticTask = Task { @MainActor [weak self] in
            if delay > 0 {
              do { try await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000)) }
              catch { return }
            }
            let end = Date().addingTimeInterval(duration)
            while !Task.isCancelled, self?.playing == true, Date() < end {
              if UIApplication.shared.applicationState == .active { AudioServicesPlaySystemSound(kSystemSoundID_Vibrate) }
              do { try await Task.sleep(nanoseconds: 2_000_000_000) } catch { return }
            }
          }
        }
      } catch { stopPlayback(); throw error }
    }
    func stopPlayback() {
      playbackGeneration = UUID()
      playbackStopper?.cancel(); playbackStopper = nil
      hapticTask?.cancel(); hapticTask = nil; player?.stop(); player = nil
      playbackTimer?.invalidate(); playbackTimer = nil
      playing = false; playbackID = nil; playbackSeconds = 0
      endBackgroundTask(); deactivate()
    }
    private func endBackgroundTask() {
      guard backgroundTask != .invalid else { return }
      let id = backgroundTask; backgroundTask = .invalid
      UIApplication.shared.endBackgroundTask(id)
    }
    private func deactivate() {
      if !monitoring && !recording && !playing && !externalPlaybackActive() {
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
      }
    }
    private func interrupt() {
      let active = monitoring
      stopAllMonitoring()
      stopPlayback()
      finishRecording()
      if active {
        onInterruption?("Звук прерван системой. Возобновите сеанс, когда будете готовы.")
      }
    }
    nonisolated func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
      Task { @MainActor [weak self] in
        guard self?.player === player else { return }; self?.stopPlayback()
      }
    }
    nonisolated func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
      let url = recorder.url
      Task { @MainActor [weak self] in self?.completeRecording(url: url, success: flag) }
    }
    nonisolated func audioPlayerDecodeErrorDidOccur(_ player: AVAudioPlayer, error: Error?) {
      Task { @MainActor [weak self] in
        guard self?.player === player else { return }; self?.stopPlayback()
        self?.onError?("Не удалось воспроизвести аудио. Выберите другую запись.")
      }
    }
    nonisolated func audioRecorderEncodeErrorDidOccur(_ recorder: AVAudioRecorder, error: Error?) {
      let url = recorder.url
      Task { @MainActor [weak self] in self?.completeRecording(url: url, success: false) }
    }
  }
  private final class EnvelopeAccumulator: @unchecked Sendable {
    let bucket: Int
    var count = 0
    var energy = 0.0
    var values: [Double] = []
    var start = Date()
    init(rate: Double) {
      bucket = max(1, Int(rate / 10))
      values.reserveCapacity(600)
    }
    func append(
      _ data: UnsafePointer<Float>, count length: Int, pulse: (Date) -> Void,
      emit: ([Double], Date, Date) -> Void
    ) {
      for i in 0..<length {
        let x = Double(data[i])
        energy += x * x
        count += 1
        if count >= bucket {
          values.append(sqrt(energy / Double(count)))
          count = 0
          energy = 0
          if values.count % 10 == 0 { pulse(Date()) }
          if values.count == 600 {
            let end = Date()
            emit(values, start, end)
            values.removeAll(keepingCapacity: true)
            start = end
          }
        }
      }
    }
  }
#endif
