"""Read the immutable baseline; write the finding only in this experiment."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

experiment=Path(__file__).resolve().parents[2]
workspace=experiment.parents[1]
baseline=workspace/'Baselines/V.0.9.6'
manifest=json.loads((baseline/'manifest.json').read_text(encoding='utf8'))
target='Luma/.validation-tools/ci-repo/.git/logs/refs/remotes/origin/HEAD'
entry=next(e for e in manifest['files'] if e['path']==target)
actual=workspace/'V.0.9.6'/target
with zipfile.ZipFile(baseline/manifest['archive']['filename']) as archive:
    original=archive.read('V.0.9.6/'+target)
report={
    'checkedAtUTC':datetime.now(timezone.utc).isoformat(),
    'command':'python Baselines/V.0.9.6/verify-baseline.py --deep',
    'result':'One mismatch: Git remote HEAD reflog; all other baseline entries matched',
    'path':str(actual),
    'expectedBytes':entry['bytes'],
    'actualBytes':actual.stat().st_size,
    'expectedSHA256':entry['sha256'],
    'actualSHA256':hashlib.sha256(actual.read_bytes()).hexdigest(),
    'archiveEntrySHA256':hashlib.sha256(original).hexdigest(),
    'lastModifiedUTC':datetime.fromtimestamp(actual.stat().st_mtime,timezone.utc).isoformat(),
    'originalOverwritten':False,
    'manifestUpdated':False,
    'automaticRestorePerformed':False,
    'cause':'Not proven. This is a Git service log, not application source. GitHub Desktop was used for the separate experimental checkout; no Git command was intentionally run in V.0.9.6.',
    'followUp':'Keep the recorded baseline and original folder unchanged; do not normalize the manifest or restore over the original.'
}
(experiment/'Luma/Docs/baseline-readonly-audit.json').write_text(json.dumps(report,indent=2),encoding='utf8')
print(json.dumps(report,indent=2))
