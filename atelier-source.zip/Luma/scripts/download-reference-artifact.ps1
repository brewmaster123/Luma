param(
  [Parameter(Mandatory=$true)][ValidatePattern('^[0-9]+$')][string]$RunId,
  [ValidateSet('Luma-0.9.9-native-reference-screen','Luma-build-logs')][string]$ArtifactName='Luma-0.9.9-native-reference-screen'
)
$ErrorActionPreference='Stop'
$experimentRoot=[System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$outputRoot=[System.IO.Path]::GetFullPath((Join-Path $experimentRoot "build-logs/run-$RunId/$ArtifactName"))
if(-not $outputRoot.StartsWith($experimentRoot+[System.IO.Path]::DirectorySeparatorChar,[System.StringComparison]::OrdinalIgnoreCase)){throw 'Artifact output is outside the experiment'}
$headers=@{Accept='application/vnd.github+json';'User-Agent'='Luma-Design-Experiment'}
$metadata=Invoke-RestMethod -Uri "https://api.github.com/repos/brewmaster123/Luma/actions/runs/$RunId/artifacts" -Headers $headers
$artifact=$metadata.artifacts | Where-Object {$_.name -eq $ArtifactName -and -not $_.expired} | Select-Object -First 1
if(-not $artifact){throw 'Artifact has not been uploaded yet'}
$expected=$artifact.digest -replace '^sha256:',''
if($expected -notmatch '^[0-9a-f]{64}$'){throw 'GitHub artifact digest is missing'}
New-Item -ItemType Directory -Path $outputRoot -Force | Out-Null
$zipPath=Join-Path $outputRoot 'download.zip'
if(-not (Test-Path -LiteralPath $zipPath)){
  Invoke-WebRequest -Uri "https://nightly.link/brewmaster123/Luma/actions/runs/$RunId/$ArtifactName.zip" -OutFile $zipPath
}
$actual=(Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
if($actual -ne $expected){throw 'Downloaded artifact does not match GitHub SHA-256'}
$extractPath=Join-Path $outputRoot 'files'
if(-not (Test-Path -LiteralPath $extractPath)){
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  [System.IO.Compression.ZipFile]::ExtractToDirectory($zipPath,$extractPath)
}
$record=[ordered]@{runId=$RunId;artifactName=$ArtifactName;artifactId=$artifact.id;verifiedSHA256=$actual;matchesGitHubDigest=$true;filesPath=$extractPath;source='Public GitHub artifact via nightly.link; bytes verified against GitHub API digest'}
$record | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $outputRoot 'verification.json') -Encoding utf8
$record | ConvertTo-Json
