const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
// Compare the established pre-reference business flow without writing to its folder.
const basis=path.resolve(root,'../../V.0.9.8-Night-Sky/Luma');
// Canonicalise line endings only, matching the preserved-source text hash policy.
// All business assertions and full-section comparisons remain exact after this.
const get=(r,p)=>fs.readFileSync(path.join(r,p),'utf8').replace(/\r\n/g,'\n');
const panel=get(root,'Sources/iPhone/IndirectMethodView.swift');
const oldPanel=get(basis,'Sources/iPhone/IndirectMethodView.swift');
const model=get(root,'Sources/Platform/AppModel.swift');
const oldModel=get(basis,'Sources/Platform/AppModel.swift');
const checks=[];
function check(name,ok){checks.push({name,passed:!!ok});}
const section=(s,a,b)=>s.slice(s.indexOf(a),b?s.indexOf(b,s.indexOf(a)):undefined);
const texts=s=>[...s.matchAll(/Text\("((?:[^"\\]|\\.)*)"\)/g)].map(m=>m[1]);
const oldHelp=texts(section(oldPanel,'private struct IndirectHelpView: View')).filter(s=>s!=='Непрямой метод');
const newHelp=texts(section(panel,'private struct IndirectReferenceHelpText: View','struct SmartAlarmReferenceHelp: View'));
check('Existing indirect help exact paragraphs and queue sentence retained',JSON.stringify(oldHelp)===JSON.stringify(newHelp));
const oldSmart=texts(get(basis,'Sources/iPhone/AlarmEditor.swift')).filter(s=>s.startsWith('Будильник через AlarmKit.'));
const smart=texts(section(panel,'struct SmartAlarmReferenceHelp: View')).filter(s=>s.startsWith('Будильник через AlarmKit.'));
check('Smart help reuses existing AlarmEditor paragraph verbatim',JSON.stringify(oldSmart)===JSON.stringify(smart));
check('Existing interval picker retained unchanged',section(oldPanel,'private struct IndirectIntervalSheet: View','private struct IndirectHelpView: View').trimEnd()===section(panel,'private struct IndirectIntervalSheet: View','/// Verbatim paragraphs').trimEnd());
for(const [a,b] of [['func setIndirectInterval','func requestIndirectMethodStart'],['func requestIndirectMethodStart','func stopIndirectMethod'],['func stopIndirectMethod','func stopAllSystemAlarms']])check(a+' business implementation unchanged',section(model,a,b)===section(oldModel,a,b));
check('Alarm editor unchanged',get(root,'Sources/iPhone/AlarmEditor.swift')===get(basis,'Sources/iPhone/AlarmEditor.swift'));
check('New namespaced preference defaults false',panel.includes('@AppStorage(IndirectMethodHelpPreference.key) private var skipStartHelp = false')&&panel.includes('com.sevchlenko.luma.indirectMethod.skipStartHelp.v1'));
check('Help Continue commits preference and arms one dismissal intent',panel.includes('skipStartHelp = doNotShowAgain\n        helpContinuationPending = true\n        showingHelp = false'));
const cancel=panel.split('} cancelAction: {')[1]?.split('}')[0]??'';
check('Help Cancel cannot start or persist opt-out',cancel.includes('helpContinuationPending = false')&&cancel.includes('showingHelp = false')&&!/requestStart|prepareStart|skipStartHelp\s*=/.test(cancel));
check('Help dismissal consumes intent once before readiness',panel.includes('guard helpContinuationPending else { return }\n      helpContinuationPending = false\n      prepareStart()'));
check('Help Continue respects busy/preparing',panel.includes('.disabled(continuing || model.busy || model.systemAlarms.preparing)'));
check('Skip preference bypasses only help, preserving readiness path',panel.includes('else if skipStartHelp {\n      prepareStart()')&&panel.includes('if model.systemAlarms.acceptedLimitations { requestStart() }\n    else { readyToStart = false; showReadiness = true }'));
check('One centralized model start, one stop call',panel.split('await model.requestIndirectMethodStart()').length===2&&panel.split('await model.stopIndirectMethod()').length===2);
check('Readiness Continue intent required',panel.includes('guard readyToStart else { return }\n      readyToStart = false\n      requestStart()'));
check('Interval guards and min/max retained',panel.includes('model.indirectRunning || model.busy || startInFlight')&&panel.includes('min(60, max(10, model.indirectIntervalMinutes + delta))')&&panel.includes('ForEach(10...60, id: \\.self)'));
check('No visible question icon in indirect control',!panel.includes('questionmark'));
check('Two rules with no decorative star',panel.includes('ReferenceIndirectRule().frame')&&panel.includes('y: 12 * sy')&&!panel.includes('systemName: "star'));
check('Source-scaled geometry matches reference anchors',panel.includes('280 / 1024')&&panel.includes('742 / 1024')&&panel.includes('628 * sx')&&panel.includes('y: 345 * sy'));
check('New helper types are in existing project source',!panel.includes('import LumaReference')&&get(root,'Luma.xcodeproj/project.pbxproj').includes('IndirectMethodView.swift'));
check('Fixture uses explicit process flag',model.includes('ProcessInfo.processInfo.arguments.contains("-reference-screenshot")'));
const fixture=section(model,'    if isReferenceScreenshot {','    alarmStopSeconds = AlarmSignalDuration.validated(');
check('Fixture before store load/defaults read',model.indexOf('    if isReferenceScreenshot {')<model.indexOf('UserDefaults.standard.object('));
check('Fixture in-memory state is deterministic',fixture.includes('fixture.hour = 7')&&fixture.includes('fixture.minute = 0')&&fixture.includes('fixture.title = "Утро"')&&fixture.includes('fixture.weekdays = [2, 3, 4, 5, 6]')&&fixture.includes('IndirectMethodSettings(intervalMinutes: 30)'));
check('Fixture does not open archives or write defaults',!fixture.includes('LocalStore(')&&!fixture.includes('UserDefaults.standard.set')&&fixture.includes('return'));
check('Fixture start/resume/suspend short-circuit scheduling',model.includes('func start() async {\n    if isReferenceScreenshot { return }')&&model.includes('func resume() async {\n    if isReferenceScreenshot { isForeground = true; return }')&&model.includes('isForeground = false\n    if isReferenceScreenshot { return }\n    systemAlarms.appBecameInactive()'));
check('Production service initialization preserved', ['let audio = PhoneAudio()','let systemAlarms = SystemAlarmService()','let nightAudio = NightAudio()','let watchLink = WatchCueLink()'].every(t=>oldModel.includes(t)&&model.includes(t)));
const report={kind:'static source/flow contracts; not Xcode typecheck or native UI tests',passed:checks.every(c=>c.passed),checks,helpTextParagraphs:newHelp.length,productionAlarmCoreChanged:false,fixtureServicesNote:'Existing service constructors unchanged. Capture uses a fresh unpaired simulator and the root blocks interaction for the screenshot flag.'};
fs.writeFileSync(path.join(root,'Docs/reference-business-checks.json'),JSON.stringify(report,null,2));
for(const c of checks)console.log((c.passed?'PASS':'FAIL')+': '+c.name);
if(!report.passed)process.exitCode=1;
