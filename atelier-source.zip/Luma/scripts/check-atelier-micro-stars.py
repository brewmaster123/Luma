"""Portable geometry audit, not a SwiftUI/Xcode or rendered-pixel test.

Read the actual Swift point list and curved boundary, then independently sample
the curve and all meteor routes across the full swing. No project file is written.
"""
from pathlib import Path
import json
import math
import re

scene = Path(__file__).resolve().parents[1] / "Sources/iPhone/ReferenceNightScene.swift"
source = scene.read_text(encoding="utf-8-sig")
point_re = r"CGPoint\(x: ([\d.-]+), y: ([\d.-]+)\)"


def points(text):
    return [tuple(map(float, p)) for p in re.findall(point_re, text)]


micro = points(re.search(r"static let openingMicroStars: \[CGPoint\] = \[(.*?)\n  \]", source, re.S)[1])
shape = points(re.search(r"private static let opening: Path = \{(.*?)return path", source, re.S)[1])
anchor = points(re.search(r"static let anchor = (.*?)\n", source)[1])[0]
start, finish, c1, c2, right_bottom, right_top = shape
margin = float(re.search(r"copy\(strokingWithWidth: ([\d.]+)", source)[1]) / 2
body = re.search(r"let nx = \(local.x - ([\d.]+)\) / ([\d.]+), ny = \(local.y - ([\d.]+)\) / ([\d.]+)", source)
body_cx, body_rx, body_cy, body_ry = map(float, body.groups())
chain = re.search(r"let suspension = CGRect\(x: ([\d.-]+), y: ([\d.-]+), width: ([\d.]+), height: ([\d.]+)\)", source)
chain_x, chain_y, chain_w, chain_h = map(float, chain.groups())


def bezier(t):
    u = 1 - t
    return tuple(u**3 * start[i] + 3*u*u*t*c1[i] + 3*u*t*t*c2[i] + t**3*finish[i] for i in (0, 1))


polygon = [bezier(i/2048) for i in range(2049)] + [right_bottom, right_top]
segments = list(zip(polygon, polygon[1:] + polygon[:1]))


def local(point, angle):
    r = math.radians(-angle)
    x, y = point[0] - anchor[0], point[1] - anchor[1]
    return (anchor[0] + x*math.cos(r) - y*math.sin(r),
            anchor[1] + x*math.sin(r) + y*math.cos(r))


def inside(p):
    x, y = p
    crossings = 0
    for (ax, ay), (bx, by) in segments:
        if (ay > y) != (by > y) and x < (bx-ax)*(y-ay)/(by-ay)+ax:
            crossings += 1
    return crossings % 2 == 1


def edge_distance(p):
    best = math.inf
    for a, b in segments:
        dx, dy = b[0]-a[0], b[1]-a[1]
        length2 = dx*dx + dy*dy
        t = max(0, min(1, ((p[0]-a[0])*dx + (p[1]-a[1])*dy)/length2)) if length2 else 0
        best = min(best, math.hypot(p[0]-a[0]-t*dx, p[1]-a[1]-t*dy))
    return best


def artwork(p):
    body = ((p[0]-body_cx)/body_rx)**2 + ((p[1]-body_cy)/body_ry)**2 <= 1 and not inside(p)
    chain = chain_x <= p[0] <= chain_x+chain_w and chain_y <= p[1] <= chain_y+chain_h
    return body or chain


def strict_exclusion(p):
    # Independent dense curve approximation of the production padded Path.
    if artwork(p) or inside(p):
        return True
    if not (min(x for x, _ in polygon)-margin <= p[0] <= max(x for x, _ in polygon)+margin
            and min(y for _, y in polygon)-margin <= p[1] <= max(y for _, y in polygon)+margin):
        return False
    return edge_distance(p) <= margin


assert len(micro) == 8
assert "let radius: CGFloat = 0.36 + CGFloat(index % 3) * 0.06" in source
assert "let alpha: Double = 0.12 + 0.03 * sin(phase)" in source
micro_results = []
for angle in (-1.5, 0, 1.5):
    for p in micro:
        q = local(p, angle)
        d = edge_distance(q)
        assert inside(q), ("micro outside opening", p, angle)
        assert d > margin + 0.48, ("micro too close to rim", p, angle, d)
        assert not artwork(q), ("micro touches moon/chain", p, angle)
        assert strict_exclusion(q), ("bright stars must still be rejected", p, angle)
        micro_results.append({"point": p, "angle": angle, "boundary_distance": round(d, 3)})

# Read the actual four route pairs, then reconstruct the production deterministic
# per-event jitter. Include a full tail extension before each route's first point.
routes = re.findall(r"(?:case \d+|default): path = \((CGPoint\(x: [^\n]+)\)", source)
assert len(routes) == 4
route_pairs = [points(route) for route in routes]
meteor_samples = 0
for index in range(96):
    a, b = route_pairs[index % 4]
    a = (a[0] + (index*29) % 21 - 10, a[1] + (index*17) % 19 - 9)
    b = (b[0] + (index*11) % 23 - 11, b[1] + (index*7) % 19 - 9)
    dx, dy = b[0]-a[0], b[1]-a[1]
    length = math.hypot(dx, dy)
    extended = (a[0]-34*dx/length, a[1]-34*dy/length)
    for angle in (-1.5, 0, 1.5):
        # Segment below/above all opening/body bounds has no possible intersection.
        # Dense samples remain useful for every candidate route and its tail.
        for k in range(65):
            p = (extended[0] + (b[0]-extended[0])*k/64,
                 extended[1] + (b[1]-extended[1])*k/64)
            q = local(p, angle)
            assert not strict_exclusion(q), ("unsafe meteor route", index, angle, p)
            meteor_samples += 1

print(json.dumps({"passed": True, "scope": "Portable independent geometry audit; no Xcode or rendered-pixel claim",
    "micro_star_count": len(micro), "radius_source_px": [0.36, 0.42, 0.48],
    "opacity_range": [0.09, 0.15], "period_seconds": [19, 22, 25, 28],
    "micro_angle_checks": micro_results, "meteor_routes_checked": 96,
    "meteor_angle_samples": meteor_samples}, indent=2))
