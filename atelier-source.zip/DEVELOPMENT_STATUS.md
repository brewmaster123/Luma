# Статус 0.9.10 (26)

Подбор и интеграция шрифтов, новая политика микрозвёзд. Проверка новой нативной сборки ещё не выполнена. production-ready=false, physical-device-verified=false, installed=false.
